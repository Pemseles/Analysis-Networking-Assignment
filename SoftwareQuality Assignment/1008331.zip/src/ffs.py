import consolemenus as cm
import database as db
import menuoptions as mo
import logfeatures as lg

if __name__ == '__main__':
    lg.CreateLog()
    cm.SystemScreenLoop()