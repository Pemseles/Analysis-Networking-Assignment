import consolemenus as cm
import logfeatures as lg

if __name__ == '__main__':
    lg.CreateLog()
    cm.SystemScreenLoop()