I didn't know which image file was required (again, not mentioned in the description pdf anywhere) 
so the 3 diagrams are in both .png and .svg formats